package com.ssd.ecart.Daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import com.ssd.ecart.DbConnection.Dbutils;
import com.ssd.ecart.Dtos.OrderDto;

public class OrderDao {
	public Connection conn = null;
	public PreparedStatement ps = null;
	public ResultSet rs = null;

	public static String INSERTUSER = "INSERT INTO orders ( p_id, u_id, o_quantity, o_date) VALUES (?,?,?,?)";


	public void placeOrder(OrderDto dto) {

		try {
			
			conn = Dbutils.getConnection();
			 ps = conn.prepareStatement(INSERTUSER);
			 ps.setInt(1, dto.getId());
			 ps.setInt(2, dto.getuId());
			 ps.setInt(3, dto.getNoOfOrders());
			 ps.setDate(4, dto.getoDate());
			 
			 ps.executeUpdate();
			
			
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public void placeAllOrders(List<OrderDto> orderList) {

		try {
			
			conn = Dbutils.getConnection();
			
			for(OrderDto dto:orderList) {
			
			
			 ps = conn.prepareStatement(INSERTUSER);
			 ps.setInt(1, dto.getId());
			 ps.setInt(2, dto.getuId());
			 ps.setInt(3, dto.getNoOfOrders());
			 ps.setDate(4, dto.getoDate());
			 
			 ps.executeUpdate();
			}
			
			
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
}



			
