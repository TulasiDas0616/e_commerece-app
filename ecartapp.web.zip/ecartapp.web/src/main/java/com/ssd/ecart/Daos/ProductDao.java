package com.ssd.ecart.Daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.ssd.ecart.DbConnection.Dbutils;
import com.ssd.ecart.Dtos.ProductDto;




public class ProductDao {
	public static Connection conn = null;
	public static PreparedStatement ps = null;
	public static ResultSet rs = null;
	public static String query = "select * from products";
 
	public List<ProductDto> getAllProductDetails() {
		List<ProductDto> ProductList = new ArrayList<>();

		try {
			conn = Dbutils.getConnection();
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();
			while (rs.next()) {
				ProductDto prodto = new ProductDto();

				prodto.setId(rs.getInt(1));
				prodto.setName(rs.getString(2));
				prodto.setCategory(rs.getString(3));
				prodto.setPrice(rs.getDouble(4));
				prodto.setImage(rs.getString(5));

				ProductList.add(prodto);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ProductList;

}
}
