package com.ssd.ecart.Daos;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.ssd.ecart.DbConnection.Dbutils;
import com.ssd.ecart.Dtos.UserDto;

public class UserLogInDao {
	public static Connection con=null;
	public static PreparedStatement ps=null;
	public static ResultSet rs=null;
	public static String User_login="select * from users where email=? and password=?";
//	id, name, email, password, address
public  UserDto LoginCredinalsByUser(UserDto dtos) {
	UserDto userdto=null;
	try {
		con=Dbutils.getConnection();
		ps=con.prepareStatement(User_login);
		ps.setString(1, dtos.getEmail());
		ps.setString(2, dtos.getPassword());
		
		rs=ps.executeQuery();
		while(rs.next()) {
			userdto=new UserDto();
			userdto.setId(rs.getInt(1));
			userdto.setName(rs.getString(2));
			userdto.setEmail(rs.getString(3));
			userdto.setPassword(rs.getString(4));
			userdto.setMobileno(rs.getLong(5));
			userdto.setAddress(rs.getString(6));
			
		}
		
	} catch (Exception e) {
		// TODO: handle exception
	}
	
	return userdto;
	
}

}
