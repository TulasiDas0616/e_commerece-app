package com.ssd.ecart.Daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.ssd.ecart.DbConnection.Dbutils;
import com.ssd.ecart.Dtos.UserDto;

public class UserSignUpDao {
	public static Connection con=null;
	public static PreparedStatement ps=null;
	public static ResultSet rs=null;
//	id, name, email, password, address
	public  String User_singup="insert into users(name, email, password, mobileno,address) values(?,?,?,?,?)";
	public  UserDto CreateUserbyFields(UserDto dtos) {
		
		try {
			con=Dbutils.getConnection();
			ps=con.prepareStatement(User_singup);
			ps.setString(1, dtos.getName());
			ps.setString(2, dtos.getEmail());
			ps.setString(3, dtos.getPassword());
			ps.setLong(4, dtos.getMobileno());
			ps.setString(5, dtos.getAddress());
			int noofrecors=ps.executeUpdate();
			System.out.println(noofrecors);
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return dtos;
		
	}

}
