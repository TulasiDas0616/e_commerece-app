package com.ssd.ecart.DbConnection;

import java.sql.Connection;
import java.sql.DriverManager;


public class Dbutils {
	
	public static Connection conn= null;
	

	public static Connection getConnection() {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/e_commerce.app", "root", "root");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return conn;
		
	}

	
}
