package com.ssd.ecart.Dtos;

public class CartDto  extends ProductDto{

	public CartDto() {
		// TODO Auto-generated constructor stub
	}
	public Integer quantity;
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public CartDto(Integer id, String name, String category, Double price, String image, Integer quantity) {
		super(id, name, category, price, image);
		this.quantity = quantity;
	}
	public CartDto(Integer quantity) {
		super();
		this.quantity = quantity;
	}
	
	@Override
	public String toString() {
		return "CartDto [quantity=" + quantity + ", getQuantity()=" + getQuantity() + ", getId()=" + getId()
				+ ", getName()=" + getName() + ", getCategory()=" + getCategory() + ", getPrice()=" + getPrice()
				+ ", getImage()=" + getImage() + ", toString()=" + super.toString() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + "]";
	}
	

}
