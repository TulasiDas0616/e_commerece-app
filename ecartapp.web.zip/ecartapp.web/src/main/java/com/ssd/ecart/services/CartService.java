package com.ssd.ecart.services;

import java.util.List;

import com.ssd.ecart.Daos.CartDao;
import com.ssd.ecart.Dtos.CartDto;

public class CartService {
public CartDao dao = new CartDao();
	
	public List<CartDto> getAllProductsByCartList(List<CartDto> OldCartList ){
		return dao.getAllProducts(OldCartList);
		
	}
	public void saveCartData(List<CartDto> cartList,Integer uid) {
		dao.saveCartData(cartList,uid);
	}
	
	public List<CartDto> getCartListByUserId(Integer uId){
		return dao.getCartList(uId);
	}
	
	public void removeCrtListByUserId(Integer uId){
		dao.revomeCrtListByUserId(uId);
	}

}
