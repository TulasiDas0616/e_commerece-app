package com.ssd.ecart.services;

import java.util.List;

import com.ssd.ecart.Daos.OrderDao;
import com.ssd.ecart.Dtos.OrderDto;

public class OrderService {
	private OrderDao dao = new OrderDao();
	public void placeYourOrder(OrderDto dto) {
		dao.placeOrder(dto);
	}
	
	
	public void placeAllYourOrders(List<OrderDto> orderList) {
		// TODO Auto-generated method stub
		dao.placeAllOrders(orderList);
	}


}
