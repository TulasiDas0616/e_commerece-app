package com.ssd.ecart.services;

import java.util.List;


import com.ssd.ecart.Daos.ProductDao;
import com.ssd.ecart.Dtos.ProductDto;

public class ProductService {
	ProductDao dao = new ProductDao();
	public List<ProductDto> getAllProductDetails() {

		return dao.getAllProductDetails();
	}
	
}
