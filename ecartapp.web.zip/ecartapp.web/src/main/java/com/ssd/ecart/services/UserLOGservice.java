package com.ssd.ecart.services;

import com.ssd.ecart.Daos.UserLogInDao;
import com.ssd.ecart.Dtos.UserDto;

public class UserLOGservice {
		public  UserDto AllLogInCredinalsByUser(UserDto dto) {
			UserLogInDao dao= new UserLogInDao();
			
	
			return  dao.LoginCredinalsByUser(dto);
		
	}

}
