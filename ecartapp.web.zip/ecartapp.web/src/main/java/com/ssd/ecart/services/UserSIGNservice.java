package com.ssd.ecart.services;

import com.ssd.ecart.Daos.UserSignUpDao;
import com.ssd.ecart.Dtos.UserDto;

public class UserSIGNservice {
	 
	public  void  AllUserDetailsByUsers(UserDto dto) {
		UserSignUpDao daos=new UserSignUpDao();
		daos.CreateUserbyFields(dto);
		
		
	}
	

}
