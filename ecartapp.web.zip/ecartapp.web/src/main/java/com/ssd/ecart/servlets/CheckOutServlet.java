package com.ssd.ecart.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssd.ecart.Dtos.CartDto;
import com.ssd.ecart.services.CartService;

/**
 * Servlet implementation class CheckOutServlet
 */
@WebServlet("/checkoutcart")
public class CheckOutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckOutServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		CartService crs = new CartService();
		
		List<CartDto> cartList =  (List<CartDto>) request.getSession().getAttribute("OldCartList");
	
		List<CartDto> newCartList  = crs.getAllProductsByCartList(cartList);
		
		System.out.println(newCartList);
		double toatlPrice = 0.0;
		
		for(CartDto dto:newCartList) {
			toatlPrice = toatlPrice + dto.getPrice();
		} 
		
		request.setAttribute("toatlPrice", toatlPrice);
		request.getSession().setAttribute("OldCartList", newCartList);
		
		request.getRequestDispatcher("Cart.jsp").forward(request, response);
	}



	}

		
		
	


