package com.ssd.ecart.servlets;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssd.ecart.Dtos.CartDto;
import com.ssd.ecart.Dtos.OrderDto;
import com.ssd.ecart.Dtos.UserDto;
import com.ssd.ecart.services.OrderService;

/**
 * Servlet implementation class CheckoutAllProductServlet
 */
@WebServlet("/cart-check-out")
public class CheckoutAllProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckoutAllProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		List<CartDto> cartList =  (List<CartDto>) request.getSession().getAttribute("OldCartList");
		UserDto user = (UserDto) request.getSession().getAttribute("user");
		
		if(user==null) {
			response.sendRedirect("UserLogIn.jsp");
			return;
		}
		List<OrderDto> orderList =new ArrayList<>();
		
		for(CartDto cartDto:cartList) {
			
			LocalDate oDate = LocalDate.now();
			
			Date date = Date.valueOf(oDate);
			
			OrderDto oDto = new OrderDto();
			
			oDto.setId(cartDto.getId());
			oDto.setuId(user.getId());
			oDto.setNoOfOrders(cartDto.getQuantity());
			oDto.setoDate(date);
			
			orderList.add(oDto);
		}
		cartList.clear(); 
		OrderService oService = new OrderService();
		
		oService.placeAllYourOrders(orderList);
		request.getRequestDispatcher("Product").forward(request, response);
	}

}
