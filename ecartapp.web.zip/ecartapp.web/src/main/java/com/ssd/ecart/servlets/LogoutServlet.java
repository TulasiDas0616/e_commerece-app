package com.ssd.ecart.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssd.ecart.Dtos.CartDto;
import com.ssd.ecart.Dtos.UserDto;
import com.ssd.ecart.services.CartService;

/**
 * Servlet implementation class LogoutServlet
 */
@WebServlet("/logout")
public class LogoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LogoutServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
List<CartDto> oldCartList = (List<CartDto>) request.getSession().getAttribute("OldCartList");
		
		UserDto userDto = (UserDto) request.getSession().getAttribute("user");
		
		if (userDto == null) {
			response.sendRedirect("UserLogIn.jsp");
			return;
		}

		
		CartService service = new CartService();
		if(oldCartList!=null && oldCartList.size()>0  ) {
		service.saveCartData(oldCartList,userDto.getId() );
		}
		
		request.getSession().removeAttribute("OldCartList");
		request.getSession().removeAttribute("user");
		response.sendRedirect("UserLogIn.jsp");
	}



	}


