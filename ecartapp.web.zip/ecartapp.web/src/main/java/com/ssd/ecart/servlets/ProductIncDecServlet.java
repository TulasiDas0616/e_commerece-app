package com.ssd.ecart.servlets;

import java.io.IOException;

import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssd.ecart.Dtos.CartDto;

/**
 * Servlet implementation class ProductIncDecServlet
 */
@WebServlet("/quantity-inc-dec")
public class ProductIncDecServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String action = request.getParameter("action");
		Integer productId = Integer.valueOf(request.getParameter("id"));
		List<CartDto> oldCartList = (List<CartDto>) request.getSession().getAttribute("OldCartList");

		System.out.println("action/...." + action);

		System.out.println("productId..." + productId);
		int produtIndex = 0;
		for (CartDto cartDto : oldCartList) {

			if (cartDto.getId() == productId) {
				produtIndex = oldCartList.indexOf(cartDto);
			}
		}
		CartDto newCartDto = new CartDto();

		CartDto dto = oldCartList.get(produtIndex);

		
		newCartDto.setId(dto.getId());
		newCartDto.setName(dto.getName());
		newCartDto.setCategory(dto.getCategory());
		newCartDto.setPrice(dto.getPrice());
		oldCartList.remove(produtIndex);
		
		
		if (action.equals("inc")) {
			
			newCartDto.setQuantity(dto.getQuantity() + 1);
			
			oldCartList.add(produtIndex, newCartDto);
			
		} else {
			
			newCartDto.setQuantity(dto.getQuantity() - 1);
			oldCartList.add(produtIndex, newCartDto);
		}
		

		request.getSession().setAttribute("OldCartList", oldCartList);

		request.getRequestDispatcher("checkoutcart").forward(request, response);

	

	}

}
