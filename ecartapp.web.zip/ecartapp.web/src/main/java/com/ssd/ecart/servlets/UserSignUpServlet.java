package com.ssd.ecart.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssd.ecart.Dtos.UserDto;
import com.ssd.ecart.services.UserSIGNservice;

/**
 * Servlet implementation class UserSignUpServlet
 */
@WebServlet("/UserSignUp")
public class UserSignUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserSignUpServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		UserSIGNservice  UserSIGNservice=new UserSIGNservice();
		try {
		
		String CNAME=request.getParameter("uname");
		String CPWD=request.getParameter("upwd");
		Long CMOB=Long.valueOf(request.getParameter("umno"));
		String errormsg="plz enter valid user's::";
		boolean isValid=false;
		
		if(CNAME==null||CNAME.isBlank()||CNAME.isEmpty()) {
			isValid=true;
			 errormsg= errormsg+"CNAME";
		}
		 if(CPWD==null||CPWD.isBlank()||CPWD.isEmpty()) {
			isValid=true;
			errormsg= errormsg+"CPWD";
		 }
//		if(CMOB==null||CMOB.SIZE()>=10||CMOB.isEmpty()) {
//			isValid=true;
//			errormsg= errormsg+"CMOB";
//			
//		}
		if(!isValid) {
	
		UserDto dto =new UserDto();
		dto.setName(request.getParameter("uname"));
		dto.setEmail(request.getParameter("uemail"));
		dto.setPassword(request.getParameter("upwd"));
		dto.setMobileno(Long.valueOf(request.getParameter("umno")));
		dto.setAddress(request.getParameter("uaddr"));
		UserSIGNservice.AllUserDetailsByUsers(dto);
		RequestDispatcher rd=request.getRequestDispatcher ("UserLogIn.jsp");
		rd.forward(request, response);
		}
		else {
				request.setAttribute("errormsg",errormsg );
				request.setAttribute("isValid", isValid);
			RequestDispatcher rd=request.getRequestDispatcher ("UserSignUp.jsp");
			rd.forward(request, response);
			
		}
		}catch (Exception e) {
			// TODO: handle exception
		}
	}

}
